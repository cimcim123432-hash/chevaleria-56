export type PortalRoute =
  | 'inicio'
  | 'historia'
  | 'atuacao'
  | 'documentos'
  | 'locais'
  | 'admin';

export interface PortalConfig {
  nome: string;
  numero: string;
  fundacao: string;
  jurisdicao: string;
  patrono: string;
  cidadeSede: string;
  endereco: string;
  emailContato: string;
  horarioSessoes: string;
  lema: string;
  gestaoAtual: string;
  resumoInstitucional: string;
  historiaTexto: string;
  patronoTexto: string;
  atuacaoTexto: string;
}

export interface AtuacaoPilar {
  id: string;
  titulo: string;
  subtitulo: string;
  descricao: string;
}

export interface LocalAtuacao {
  id: string;
  nome: string;
  cidade: string;
  tipo: string;
  descricao: string;
  imagemUrl?: string;
}

export interface DocumentoHistorico {
  id: string;
  titulo: string;
  tipo: string;
  dataDocumento: string;
  orgaoEmissor: string;
  descricao: string;
  detalhes?: string;
  imagemUrl: string;
}

export interface TimelineMilestone {
  id: string;
  ano: string;
  titulo: string;
  descricao: string;
}

export type GalleryCategory = 'Sede e Templo' | 'Cerimônias' | 'Símbolos Oficiais';

export interface GalleryItem {
  id: string;
  titulo: string;
  categoria: GalleryCategory;
  legenda: string;
  imagemUrl: string;
  ano: string;
  figNumero: string;
}

export interface ContactMessage {
  id: string;
  nome: string;
  email: string;
  capituloOuInstituicao: string;
  assunto: string;
  mensagem: string;
  dataEnvio: string;
  status: 'Nova' | 'Lida' | 'Arquivada';
}

export interface PortalData {
  config: PortalConfig;
  atuacaoPilares: AtuacaoPilar[];
  locais: LocalAtuacao[];
  documentos: DocumentoHistorico[];
  timeline: TimelineMilestone[];
  galeria: GalleryItem[];
  mensagens: ContactMessage[];
}
