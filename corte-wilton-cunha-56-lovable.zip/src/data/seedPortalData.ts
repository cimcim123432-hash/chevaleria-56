import { PortalData } from '../types';

export const SEED_PORTAL_DATA: PortalData = {
  "config": {
    "nome": "Corte Chevalier Wilton Cunha Nº 56",
    "numero": "56",
    "fundacao": "14 de abril de 2004",
    "jurisdicao": "Grande Capítulo do Estado de Rondônia (GCE-RO)",
    "patrono": "Wilton Cunha",
    "cidadeSede": "Porto Velho, Rondônia",
    "endereco": "Palácio Maçônico Euclides Sampaio Fróes — Porto Velho, RO",
    "emailContato": "chancelaria@cortewiltoncunha56.org.br",
    "horarioSessoes": "Palácio Maçônico Euclides Sampaio Fróes · Porto Velho, Rondônia",
    "lema": "Valorizar a honraria Chevalier e reconhecer a dedicação e os serviços prestados à Ordem DeMolay",
    "gestaoAtual": "Ordem DeMolay · GCE-RO",
    "resumoInstitucional": "Vinculada à Ordem DeMolay no Estado de Rondônia, sob jurisdição do Grande Capítulo do Estado de Rondônia (GCE-RO), com a finalidade de valorizar a honraria Chevalier e reconhecer a dedicação e os serviços prestados à Ordem DeMolay.",
    "historiaTexto": "Fundada em 14 de abril de 2004, a Corte Chevalier Wilton Cunha Nº 56 é vinculada à Ordem DeMolay no Estado de Rondônia, sob jurisdição do Grande Capítulo do Estado de Rondônia (GCE-RO).\n\nPor meio de Carta Constitutiva Temporária expedida em 18 de maio de 2004 na cidade do Rio de Janeiro, o Supremo Conselho da Ordem DeMolay para o Brasil autorizou o Grande Oriente Estadual de Rondônia / GOB, localizado em Porto Velho, a instalar e patrocinar a Corte de Chevaliers \"Wilton Cunha\" Nº 056 da Ordem DeMolay, nomeando para compor seu Conselho Consultivo inicial os Maçons Euclides Sampaio Froes, Almerindo Brito de Souza e Cláudio Luiz do Amaral Santini.",
    "patronoTexto": "A Corte recebe o nome de Wilton Cunha como Patrono institucional, perpetuando sua memória e referência junto à Ordem DeMolay no Estado de Rondônia.",
    "atuacaoTexto": "A Corte Chevalier Wilton Cunha Nº 56 atua junto à Ordem DeMolay no Estado de Rondônia, sob jurisdição do Grande Capítulo do Estado de Rondônia (GCE-RO), com o propósito de valorizar a honraria Chevalier e reconhecer a dedicação e os serviços prestados à Ordem DeMolay."
  },
  "atuacaoPilares": [
    {
      "id": "pil-1",
      "titulo": "Valorização da Honraria Chevalier",
      "subtitulo": "Finalidade Institucional",
      "descricao": "Preservar o significado, o respeito e a solenidade da honraria Chevalier junto aos membros e Capítulos vinculados ao Grande Capítulo do Estado de Rondônia."
    },
    {
      "id": "pil-2",
      "titulo": "Reconhecimento do Mérito e Serviço",
      "subtitulo": "Dedicação à Ordem DeMolay",
      "descricao": "Reconhecer a dedicação, a constância e os serviços prestados à Ordem DeMolay no Estado de Rondônia."
    }
  ],
  "locais": [
    {
      "id": "loc-1",
      "nome": "Palácio Maçônico Euclides Sampaio Fróes",
      "cidade": "Porto Velho · Rondônia",
      "tipo": "Sede Oficial",
      "descricao": "Localizado em Porto Velho, Rondônia, o Palácio Maçônico Euclides Sampaio Fróes abriga as atividades da Corte Chevalier Wilton Cunha Nº 56.",
      "imagemUrl": "/assets/aistudio/local_977dc478.jpg"
    }
  ],
  "documentos": [
    {
      "id": "doc-1",
      "titulo": "Carta Constitutiva Temporária — Corte de Chevaliers \"Wilton Cunha\" Nº 056",
      "tipo": "Carta Constitutiva Temporária",
      "dataDocumento": "18 de maio de 2004",
      "orgaoEmissor": "Supremo Conselho da Ordem DeMolay para o Brasil",
      "descricao": "Autorização concedida ao Grande Oriente Estadual de Rondônia / GOB, em Porto Velho (RO), para instalar e patrocinar a Corte de Chevaliers \"Wilton Cunha\" Nº 056 da Ordem DeMolay.",
      "detalhes": "Conselho Consultivo nomeado no documento: Euclides Sampaio Froes, Almerindo Brito de Souza e Cláudio Luiz do Amaral Santini. Assinado no Rio de Janeiro / RJ em 18 de maio de 2004 por Alberto Mansur (Grande Mestre), Geraldo dos Santos (Grande Secretário Geral) e Almerindo Brito dos Santos (Deputado Estadual da Ordem DeMolay / Rondônia).",
      "imagemUrl": "/assets/aistudio/WhatsApp_Image_2026-11-22_at_00.30.12_32807d4f.jpeg"
    }
  ],
  "timeline": [
    {
      "id": "tl-1",
      "ano": "14/04/2004",
      "titulo": "Fundação da Corte Chevalier Wilton Cunha Nº 56",
      "descricao": "Data de fundação da Corte Chevalier Wilton Cunha Nº 56 em Rondônia."
    },
    {
      "id": "tl-2",
      "ano": "18/05/2004",
      "titulo": "Carta Constitutiva Temporária",
      "descricao": "Expedição da Carta Constitutiva Temporária pelo Supremo Conselho da Ordem DeMolay para o Brasil autorizando o Grande Oriente Estadual de Rondônia / GOB a instalar e patrocinar a Corte Nº 056 em Porto Velho."
    }
  ],
  "galeria": [
    {
      "id": "gal-1",
      "titulo": "Palácio Maçônico Euclides Sampaio Fróes",
      "categoria": "Sede e Templo",
      "legenda": "",
      "imagemUrl": "/assets/aistudio/local_977dc478.jpg",
      "ano": "",
      "figNumero": ""
    },
    {
      "id": "gal-2",
      "titulo": "Acervo da Corte Nº 56",
      "categoria": "Cerimônias",
      "legenda": "",
      "imagemUrl": "/assets/aistudio/wilton_cunha_1b7e0e69.png",
      "ano": "",
      "figNumero": ""
    },
    {
      "id": "gal-3",
      "titulo": "Brasão da Corte Chevalier Wilton Cunha Nº 56",
      "categoria": "Símbolos Oficiais",
      "legenda": "",
      "imagemUrl": "/assets/aistudio/logo_wilton_cunha_90fec92e.jpg",
      "ano": "",
      "figNumero": ""
    }
  ],
  "mensagens": []
};
