import { PortalConfig, PortalData } from '../types';
import { SEED_PORTAL_DATA } from '../data/seedPortalData';

function authHeaders(token: string) {
  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  };
}

export async function fetchPublicPortalData(): Promise<PortalData> {
  try {
    const res = await fetch('/api/portal');
    const contentType = res.headers.get('content-type') || '';
    if (res.ok && contentType.includes('application/json')) {
      return await res.json();
    }
  } catch {
    // Fallback to static institutional data when hosted as static SPA
  }
  return SEED_PORTAL_DATA;
}

export async function submitContactMessage(payload: {
  nome: string;
  email: string;
  capituloOuInstituicao: string;
  assunto: string;
  mensagem: string;
}): Promise<{ ok: boolean; error?: string }> {
  const res = await fetch('/api/mensagens', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const json = await res.json();
  if (!res.ok) {
    return { ok: false, error: json.error || 'Não foi possível enviar sua mensagem.' };
  }
  return { ok: true };
}

export async function loginCAA(
  email: string,
  password: string
): Promise<{ ok: boolean; token?: string; error?: string }> {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  const json = await res.json();
  if (!res.ok) {
    return { ok: false, error: json.error || 'Falha de autenticação.' };
  }
  return { ok: true, token: json.token };
}

export async function fetchAdminPortalData(
  token: string
): Promise<{ unauthorized?: boolean; data?: PortalData }> {
  const res = await fetch('/api/admin/portal', {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (res.status === 401) return { unauthorized: true };
  if (!res.ok) return {};
  return { data: await res.json() };
}

export async function savePortalConfig(
  token: string,
  config: PortalConfig
): Promise<{ ok: boolean; unauthorized?: boolean }> {
  const res = await fetch('/api/admin/config', {
    method: 'PUT',
    headers: authHeaders(token),
    body: JSON.stringify(config),
  });
  if (res.status === 401) return { ok: false, unauthorized: true };
  return { ok: res.ok };
}

export async function addPortalDocumento(
  token: string,
  payload: Record<string, string>
): Promise<{ ok: boolean; unauthorized?: boolean }> {
  const res = await fetch('/api/admin/documentos', {
    method: 'POST',
    headers: authHeaders(token),
    body: JSON.stringify(payload),
  });
  if (res.status === 401) return { ok: false, unauthorized: true };
  return { ok: res.ok };
}

export async function deletePortalDocumento(
  token: string,
  id: string
): Promise<{ ok: boolean; unauthorized?: boolean }> {
  const res = await fetch(`/api/admin/documentos/${id}`, {
    method: 'DELETE',
    headers: authHeaders(token),
  });
  if (res.status === 401) return { ok: false, unauthorized: true };
  return { ok: res.ok };
}

export async function addPortalPilar(
  token: string,
  payload: { titulo: string; subtitulo: string; descricao: string }
): Promise<{ ok: boolean; unauthorized?: boolean }> {
  const res = await fetch('/api/admin/atuacao', {
    method: 'POST',
    headers: authHeaders(token),
    body: JSON.stringify(payload),
  });
  if (res.status === 401) return { ok: false, unauthorized: true };
  return { ok: res.ok };
}

export async function deletePortalPilar(
  token: string,
  id: string
): Promise<{ ok: boolean; unauthorized?: boolean }> {
  const res = await fetch(`/api/admin/atuacao/${id}`, {
    method: 'DELETE',
    headers: authHeaders(token),
  });
  if (res.status === 401) return { ok: false, unauthorized: true };
  return { ok: res.ok };
}

export async function addPortalLocal(
  token: string,
  payload: { nome: string; cidade: string; tipo: string; descricao: string }
): Promise<{ ok: boolean; unauthorized?: boolean }> {
  const res = await fetch('/api/admin/locais', {
    method: 'POST',
    headers: authHeaders(token),
    body: JSON.stringify(payload),
  });
  if (res.status === 401) return { ok: false, unauthorized: true };
  return { ok: res.ok };
}

export async function deletePortalLocal(
  token: string,
  id: string
): Promise<{ ok: boolean; unauthorized?: boolean }> {
  const res = await fetch(`/api/admin/locais/${id}`, {
    method: 'DELETE',
    headers: authHeaders(token),
  });
  if (res.status === 401) return { ok: false, unauthorized: true };
  return { ok: res.ok };
}

export async function addPortalTimeline(
  token: string,
  payload: { ano: string; titulo: string; descricao: string }
): Promise<{ ok: boolean; unauthorized?: boolean }> {
  const res = await fetch('/api/admin/timeline', {
    method: 'POST',
    headers: authHeaders(token),
    body: JSON.stringify(payload),
  });
  if (res.status === 401) return { ok: false, unauthorized: true };
  return { ok: res.ok };
}

export async function deletePortalTimeline(
  token: string,
  id: string
): Promise<{ ok: boolean; unauthorized?: boolean }> {
  const res = await fetch(`/api/admin/timeline/${id}`, {
    method: 'DELETE',
    headers: authHeaders(token),
  });
  if (res.status === 401) return { ok: false, unauthorized: true };
  return { ok: res.ok };
}

export async function updatePortalMensagemStatus(
  token: string,
  id: string,
  status: 'Lida' | 'Arquivada'
): Promise<{ ok: boolean; unauthorized?: boolean }> {
  const res = await fetch(`/api/admin/mensagens/${id}`, {
    method: 'PUT',
    headers: authHeaders(token),
    body: JSON.stringify({ status }),
  });
  if (res.status === 401) return { ok: false, unauthorized: true };
  return { ok: res.ok };
}

export async function deletePortalMensagem(
  token: string,
  id: string
): Promise<{ ok: boolean; unauthorized?: boolean }> {
  const res = await fetch(`/api/admin/mensagens/${id}`, {
    method: 'DELETE',
    headers: authHeaders(token),
  });
  if (res.status === 401) return { ok: false, unauthorized: true };
  return { ok: res.ok };
}
