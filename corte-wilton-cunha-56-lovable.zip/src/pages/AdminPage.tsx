import { ChangeEvent, FormEvent, useCallback, useEffect, useState } from 'react';
import {
  Check,
  LogOut,
  Mail,
  Plus,
  ShieldCheck,
  Trash2,
  Upload,
} from 'lucide-react';
import {
  PortalConfig,
  PortalData,
} from '../types';
import { PORTAL_ASSETS } from '../constants/assets';
import {
  addPortalDocumento,
  addPortalLocal,
  addPortalPilar,
  addPortalTimeline,
  deletePortalDocumento,
  deletePortalLocal,
  deletePortalMensagem,
  deletePortalPilar,
  deletePortalTimeline,
  fetchAdminPortalData,
  loginCAA,
  savePortalConfig,
  updatePortalMensagemStatus,
} from '../services/portalService';

interface AdminPageProps {
  token: string | null;
  onLoginSuccess: (token: string) => void;
  onLogout: () => void;
  onPublicDataUpdated: () => Promise<void>;
}

type AdminTab =
  | 'geral'
  | 'documentos'
  | 'atuacao-locais'
  | 'cronologia'
  | 'mensagens';

export function AdminPage({
  token,
  onLoginSuccess,
  onLogout,
  onPublicDataUpdated,
}: AdminPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [loggingIn, setLoggingIn] = useState(false);

  const [tab, setTab] = useState<AdminTab>('geral');
  const [adminData, setAdminData] = useState<PortalData | null>(null);
  const [loadingData, setLoadingData] = useState(false);
  const [feedback, setFeedback] = useState('');

  const [configForm, setConfigForm] = useState<PortalConfig | null>(null);

  const [newDoc, setNewDoc] = useState({
    titulo: '',
    tipo: 'Carta Constitutiva',
    dataDocumento: '',
    orgaoEmissor: 'Supremo Conselho da Ordem DeMolay para o Brasil',
    descricao: '',
    detalhes: '',
    imagemUrl: PORTAL_ASSETS.CARTA_CONSTITUTIVA as string,
    imageBase64: '',
  });

  const [newPilar, setNewPilar] = useState({
    titulo: '',
    subtitulo: '',
    descricao: '',
  });

  const [newLocal, setNewLocal] = useState({
    nome: '',
    cidade: '',
    tipo: 'Local de Atuação',
    descricao: '',
  });

  const [newTimeline, setNewTimeline] = useState({
    ano: '',
    titulo: '',
    descricao: '',
  });

  const showToast = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(''), 3500);
  };

  const fetchAdminData = useCallback(async () => {
    if (!token) return;
    setLoadingData(true);
    try {
      const result = await fetchAdminPortalData(token);
      if (result.unauthorized) {
        onLogout();
        return;
      }
      if (result.data) {
        setAdminData(result.data);
        setConfigForm(result.data.config);
      }
    } finally {
      setLoadingData(false);
    }
  }, [token, onLogout]);

  useEffect(() => {
    if (token) {
      fetchAdminData();
    } else {
      setAdminData(null);
    }
  }, [token, fetchAdminData]);

  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoggingIn(true);
    try {
      const result = await loginCAA(email, password);
      if (!result.ok || !result.token) {
        setLoginError(result.error || 'Falha de autenticação.');
      } else {
        onLoginSuccess(result.token);
      }
    } catch {
      setLoginError('Erro de conexão com o servidor.');
    } finally {
      setLoggingIn(false);
    }
  };

  const saveConfig = async (e: FormEvent) => {
    e.preventDefault();
    if (!configForm || !token) return;
    const res = await savePortalConfig(token, configForm);
    if (res.unauthorized) {
      onLogout();
      return;
    }
    if (res.ok) {
      await fetchAdminData();
      await onPublicDataUpdated();
      showToast('Informações e textos do site atualizados pelo CAA.');
    }
  };

  const handleDocFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setNewDoc((prev) => ({ ...prev, imageBase64: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const addDocumento = async (e: FormEvent) => {
    e.preventDefault();
    if (!token) return;
    const res = await addPortalDocumento(token, newDoc);
    if (res.unauthorized) {
      onLogout();
      return;
    }
    if (res.ok) {
      setNewDoc({
        titulo: '',
        tipo: 'Documento Oficial',
        dataDocumento: '',
        orgaoEmissor: 'Corte Chevalier Wilton Cunha Nº 56',
        descricao: '',
        detalhes: '',
        imagemUrl: PORTAL_ASSETS.CARTA_CONSTITUTIVA,
        imageBase64: '',
      });
      await fetchAdminData();
      await onPublicDataUpdated();
      showToast('Documento publicado na aba Documentos.');
    }
  };

  const deleteDocumento = async (id: string) => {
    if (!token) return;
    const res = await deletePortalDocumento(token, id);
    if (res.unauthorized) {
      onLogout();
      return;
    }
    if (res.ok) {
      await fetchAdminData();
      await onPublicDataUpdated();
      showToast('Documento removido.');
    }
  };

  const addPilar = async (e: FormEvent) => {
    e.preventDefault();
    if (!token) return;
    const res = await addPortalPilar(token, newPilar);
    if (res.unauthorized) {
      onLogout();
      return;
    }
    if (res.ok) {
      setNewPilar({ titulo: '', subtitulo: '', descricao: '' });
      await fetchAdminData();
      await onPublicDataUpdated();
      showToast('Frente de atuação adicionada.');
    }
  };

  const deletePilar = async (id: string) => {
    if (!token) return;
    const res = await deletePortalPilar(token, id);
    if (res.unauthorized) {
      onLogout();
      return;
    }
    if (res.ok) {
      await fetchAdminData();
      await onPublicDataUpdated();
      showToast('Frente de atuação removida.');
    }
  };

  const addLocal = async (e: FormEvent) => {
    e.preventDefault();
    if (!token) return;
    const res = await addPortalLocal(token, newLocal);
    if (res.unauthorized) {
      onLogout();
      return;
    }
    if (res.ok) {
      setNewLocal({ nome: '', cidade: '', tipo: 'Local de Atuação', descricao: '' });
      await fetchAdminData();
      await onPublicDataUpdated();
      showToast('Local adicionado ao portal.');
    }
  };

  const deleteLocal = async (id: string) => {
    if (!token) return;
    const res = await deletePortalLocal(token, id);
    if (res.unauthorized) {
      onLogout();
      return;
    }
    if (res.ok) {
      await fetchAdminData();
      await onPublicDataUpdated();
      showToast('Local removido.');
    }
  };

  const addTimelineItem = async (e: FormEvent) => {
    e.preventDefault();
    if (!token) return;
    const res = await addPortalTimeline(token, newTimeline);
    if (res.unauthorized) {
      onLogout();
      return;
    }
    if (res.ok) {
      setNewTimeline({ ano: '', titulo: '', descricao: '' });
      await fetchAdminData();
      await onPublicDataUpdated();
      showToast('Marco histórico adicionado à cronologia.');
    }
  };

  const deleteTimelineItem = async (id: string) => {
    if (!token) return;
    const res = await deletePortalTimeline(token, id);
    if (res.unauthorized) {
      onLogout();
      return;
    }
    if (res.ok) {
      await fetchAdminData();
      await onPublicDataUpdated();
      showToast('Marco histórico removido.');
    }
  };

  const updateMensagemStatus = async (id: string, status: 'Lida' | 'Arquivada') => {
    if (!token) return;
    const res = await updatePortalMensagemStatus(token, id, status);
    if (res.unauthorized) {
      onLogout();
      return;
    }
    if (res.ok) {
      await fetchAdminData();
      showToast(`Mensagem marcada como ${status.toLowerCase()}.`);
    }
  };

  const deleteMensagem = async (id: string) => {
    if (!token) return;
    const res = await deletePortalMensagem(token, id);
    if (res.unauthorized) {
      onLogout();
      return;
    }
    if (res.ok) {
      await fetchAdminData();
      showToast('Mensagem excluída.');
    }
  };

  // Unauthenticated View — Exclusivo CAA
  if (!token) {
    return (
      <section className="min-h-[75vh] bg-[#080B10] flex items-center justify-center py-16 px-4">
        <div className="w-full max-w-md bg-[#101923] border border-[#C5A15B]/45 p-8">
          <div className="flex items-center gap-3 pb-5 border-b border-[#C5A15B]/20">
            <ShieldCheck className="w-6 h-6 text-[#C5A15B]" strokeWidth={1.5} />
            <div>
              <p className="text-[11px] uppercase tracking-[0.2em] text-[#C5A15B]">
                Administração · Acesso Exclusivo CAA
              </p>
              <h1 className="font-serif text-2xl font-semibold text-[#F3EFE5]">
                Administração do Portal
              </h1>
            </div>
          </div>

          <p className="mt-4 text-sm text-[#F3EFE5]/75 leading-relaxed">
            Área restrita exclusivamente ao <strong>CAA</strong> para edição dos dados institucionais, história, documentos, locais, frentes de atuação e acervo da Corte Chevalier Wilton Cunha Nº 56.
          </p>

          <form onSubmit={handleLogin} className="mt-6 space-y-4">
            {loginError && (
              <div className="p-3 bg-[#8B1E24]/30 border border-[#8B1E24] text-xs text-[#F3EFE5]">
                {loginError}
              </div>
            )}

            <div>
              <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-1.5">
                Credencial do CAA (E-mail)
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5] focus:outline-none focus:border-[#C5A15B]"
                placeholder="caa@..."
              />
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-1.5">
                Senha do CAA
              </label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5] focus:outline-none focus:border-[#C5A15B]"
                placeholder="••••••••••••"
              />
            </div>

            <button
              type="submit"
              disabled={loggingIn}
              className="w-full py-3 text-xs font-semibold uppercase tracking-wider bg-[#8B1E24] text-[#F3EFE5] border border-[#C5A15B]/50 hover:bg-[#A6262D] disabled:opacity-60 transition-colors cursor-pointer"
            >
              {loggingIn ? 'Verificando CAA...' : 'Entrar na Administração'}
            </button>
          </form>
        </div>
      </section>
    );
  }

  return (
    <div className="min-h-screen bg-[#080B10] text-[#F3EFE5] pb-20">
      {/* Admin Header Bar */}
      <div className="bg-[#101923] border-b border-[#C5A15B]/30 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-[#C5A15B]">
              Administração · Poder de Edição Exclusivo CAA
            </p>
            <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#F3EFE5] mt-1">
              Gestão do Portal — Corte Nº 56
            </h1>
          </div>

          <button
            type="button"
            onClick={onLogout}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold uppercase tracking-wider bg-[#080B10] text-[#E2C989] border border-[#C5A15B]/40 hover:bg-[#8B1E24] hover:text-[#F3EFE5] transition-colors cursor-pointer self-start sm:self-auto"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Encerrar Sessão CAA</span>
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
          <div className="flex flex-wrap gap-1 border-b border-[#C5A15B]/20">
            {(
              [
                ['geral', 'Informações & Textos'],
                ['documentos', 'Documentos'],
                ['atuacao-locais', 'Atuação & Locais'],
                ['cronologia', 'Cronologia'],
                ['mensagens', 'Mensagens'],
              ] as [AdminTab, string][]
            ).map(([key, label]) => {
              const active = tab === key;
              const unreadCount =
                key === 'mensagens'
                  ? adminData?.mensagens.filter((m) => m.status === 'Nova').length ?? 0
                  : 0;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setTab(key)}
                  className={`px-4 py-3 text-xs font-semibold tracking-wide border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'border-[#C5A15B] text-[#E2C989] bg-[#080B10]/50'
                      : 'border-transparent text-[#F3EFE5]/65 hover:text-[#F3EFE5]'
                  }`}
                >
                  {label}
                  {unreadCount > 0 && (
                    <span className="ml-2 text-[#C5A15B] tabular-nums">({unreadCount})</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Feedback Banner */}
      {feedback && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
          <div className="p-3.5 bg-[#101923] border border-[#C5A15B] flex items-center gap-2.5 text-sm text-[#E2C989]">
            <Check className="w-4 h-4 text-[#C5A15B]" />
            <span>{feedback}</span>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        {loadingData || !adminData ? (
          <div className="p-12 text-center bg-[#101923] border border-[#C5A15B]/20 text-sm text-[#F3EFE5]/70">
            Carregando painel do CAA...
          </div>
        ) : (
          <>
            {/* TAB 1: INFORMAÇÕES & TEXTOS */}
            {tab === 'geral' && configForm && (
              <form
                onSubmit={saveConfig}
                className="p-7 bg-[#101923] border border-[#C5A15B]/30 space-y-6"
              >
                <h2 className="font-serif text-2xl font-semibold text-[#E2C989] pb-3 border-b border-[#C5A15B]/20">
                  Editar Informações Institucionais do Site
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-1.5">
                      Nome da Corte
                    </label>
                    <input
                      type="text"
                      value={configForm.nome}
                      onChange={(e) =>
                        setConfigForm({ ...configForm, nome: e.target.value })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-1.5">
                      Gestão Atual
                    </label>
                    <input
                      type="text"
                      value={configForm.gestaoAtual}
                      onChange={(e) =>
                        setConfigForm({ ...configForm, gestaoAtual: e.target.value })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-1.5">
                      Localização / Sede Principal
                    </label>
                    <input
                      type="text"
                      value={configForm.endereco}
                      onChange={(e) =>
                        setConfigForm({ ...configForm, endereco: e.target.value })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-1.5">
                      Regime de Convocações
                    </label>
                    <input
                      type="text"
                      value={configForm.horarioSessoes}
                      onChange={(e) =>
                        setConfigForm({ ...configForm, horarioSessoes: e.target.value })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-1.5">
                      E-mail Oficial
                    </label>
                    <input
                      type="email"
                      value={configForm.emailContato}
                      onChange={(e) =>
                        setConfigForm({ ...configForm, emailContato: e.target.value })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-1.5">
                      Lema Institucional
                    </label>
                    <input
                      type="text"
                      value={configForm.lema}
                      onChange={(e) =>
                        setConfigForm({ ...configForm, lema: e.target.value })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                  </div>
                </div>

                <div className="space-y-4 pt-4 border-t border-[#C5A15B]/20">
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-1.5">
                      Resumo de Apresentação (Início)
                    </label>
                    <textarea
                      rows={2}
                      value={configForm.resumoInstitucional}
                      onChange={(e) =>
                        setConfigForm({
                          ...configForm,
                          resumoInstitucional: e.target.value,
                        })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-1.5">
                      Texto da História da Corte
                    </label>
                    <textarea
                      rows={5}
                      value={configForm.historiaTexto}
                      onChange={(e) =>
                        setConfigForm({ ...configForm, historiaTexto: e.target.value })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-1.5">
                      Texto do Patrono Wilton Cunha
                    </label>
                    <textarea
                      rows={4}
                      value={configForm.patronoTexto}
                      onChange={(e) =>
                        setConfigForm({ ...configForm, patronoTexto: e.target.value })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-1.5">
                      Texto de Como Atuamos
                    </label>
                    <textarea
                      rows={4}
                      value={configForm.atuacaoTexto}
                      onChange={(e) =>
                        setConfigForm({ ...configForm, atuacaoTexto: e.target.value })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#8B1E24] text-[#F3EFE5] border border-[#C5A15B]/50 hover:bg-[#A6262D] cursor-pointer"
                  >
                    Salvar Alterações do Site
                  </button>
                </div>
              </form>
            )}

            {/* TAB 2: DOCUMENTOS */}
            {tab === 'documentos' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                <form
                  onSubmit={addDocumento}
                  className="lg:col-span-5 p-6 bg-[#101923] border border-[#C5A15B]/30 space-y-4"
                >
                  <h2 className="font-serif text-2xl font-semibold text-[#E2C989] pb-3 border-b border-[#C5A15B]/20">
                    Publicar Foto de Documento
                  </h2>
                  <input
                    type="text"
                    required
                    placeholder="Título do Documento *"
                    value={newDoc.titulo}
                    onChange={(e) => setNewDoc({ ...newDoc, titulo: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                  />
                  <div className="grid grid-cols-2 gap-3">
                    <input
                      type="text"
                      placeholder="Tipo (Ex.: Carta Constitutiva)"
                      value={newDoc.tipo}
                      onChange={(e) => setNewDoc({ ...newDoc, tipo: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                    <input
                      type="text"
                      placeholder="Data (Ex.: 18/05/2004)"
                      value={newDoc.dataDocumento}
                      onChange={(e) =>
                        setNewDoc({ ...newDoc, dataDocumento: e.target.value })
                      }
                      className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                  </div>
                  <input
                    type="text"
                    placeholder="Órgão Emissor"
                    value={newDoc.orgaoEmissor}
                    onChange={(e) =>
                      setNewDoc({ ...newDoc, orgaoEmissor: e.target.value })
                    }
                    className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                  />

                  <div className="p-4 bg-[#080B10] border border-dashed border-[#C5A15B]/40 space-y-2">
                    <label className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#E2C989] cursor-pointer">
                      <Upload className="w-4 h-4 text-[#C5A15B]" />
                      <span>Enviar Arquivo de Foto do Documento</span>
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/webp"
                        onChange={handleDocFileChange}
                        className="sr-only"
                      />
                    </label>
                    <p className="text-[11px] text-[#F3EFE5]/60">
                      {newDoc.imageBase64
                        ? 'Nova imagem carregada e pronta para publicação.'
                        : 'Selecione uma imagem JPG, PNG ou WEBP do seu dispositivo.'}
                    </p>
                  </div>

                  <textarea
                    rows={3}
                    placeholder="Descrição do documento..."
                    value={newDoc.descricao}
                    onChange={(e) =>
                      setNewDoc({ ...newDoc, descricao: e.target.value })
                    }
                    className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                  />
                  <textarea
                    rows={2}
                    placeholder="Detalhes / Signatários (opcional)"
                    value={newDoc.detalhes}
                    onChange={(e) => setNewDoc({ ...newDoc, detalhes: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                  />
                  <button
                    type="submit"
                    className="w-full inline-flex items-center justify-center gap-2 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#8B1E24] text-[#F3EFE5] border border-[#C5A15B]/50 hover:bg-[#A6262D] cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Publicar Documento</span>
                  </button>
                </form>

                <div className="lg:col-span-7 space-y-4">
                  {adminData.documentos.map((doc) => (
                    <div
                      key={doc.id}
                      className="p-5 bg-[#101923] border border-[#C5A15B]/25 flex items-start gap-4"
                    >
                      <img
                        src={doc.imagemUrl}
                        alt={doc.titulo}
                        referrerPolicy="no-referrer"
                        className="w-20 h-28 object-cover shrink-0 border border-[#C5A15B]/30 bg-[#080B10]"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-[#C5A15B] tabular-nums">
                          {doc.tipo} · {doc.dataDocumento}
                        </p>
                        <h3 className="mt-1 font-serif text-xl text-[#F3EFE5]">
                          {doc.titulo}
                        </h3>
                        <p className="mt-1 text-xs text-[#F3EFE5]/70 line-clamp-2">
                          {doc.descricao}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => deleteDocumento(doc.id)}
                        aria-label={`Remover ${doc.titulo}`}
                        className="p-1.5 text-[#F3EFE5]/60 hover:text-[#A6262D] cursor-pointer shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: ATUAÇÃO & LOCAIS */}
            {tab === 'atuacao-locais' && (
              <div className="space-y-12">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  <form
                    onSubmit={addPilar}
                    className="lg:col-span-4 p-6 bg-[#101923] border border-[#C5A15B]/30 space-y-4"
                  >
                    <h2 className="font-serif text-2xl font-semibold text-[#E2C989] pb-3 border-b border-[#C5A15B]/20">
                      Nova Frente de Atuação
                    </h2>
                    <input
                      type="text"
                      required
                      placeholder="Título *"
                      value={newPilar.titulo}
                      onChange={(e) => setNewPilar({ ...newPilar, titulo: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                    <input
                      type="text"
                      placeholder="Subtítulo"
                      value={newPilar.subtitulo}
                      onChange={(e) =>
                        setNewPilar({ ...newPilar, subtitulo: e.target.value })
                      }
                      className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                    <textarea
                      rows={3}
                      required
                      placeholder="Descrição *"
                      value={newPilar.descricao}
                      onChange={(e) =>
                        setNewPilar({ ...newPilar, descricao: e.target.value })
                      }
                      className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                    <button
                      type="submit"
                      className="w-full inline-flex items-center justify-center gap-2 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#8B1E24] text-[#F3EFE5] border border-[#C5A15B]/50 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Adicionar Pilar</span>
                    </button>
                  </form>

                  <div className="lg:col-span-8 space-y-3">
                    {adminData.atuacaoPilares.map((p) => (
                      <div
                        key={p.id}
                        className="p-5 bg-[#101923] border border-[#C5A15B]/25 flex items-start justify-between gap-4"
                      >
                        <div>
                          <p className="text-xs text-[#C5A15B]">{p.subtitulo}</p>
                          <h3 className="font-serif text-xl text-[#F3EFE5]">{p.titulo}</h3>
                          <p className="text-xs text-[#F3EFE5]/75 mt-1">{p.descricao}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => deletePilar(p.id)}
                          className="p-1.5 text-[#F3EFE5]/60 hover:text-[#A6262D] cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start pt-8 border-t border-[#C5A15B]/20">
                  <form
                    onSubmit={addLocal}
                    className="lg:col-span-4 p-6 bg-[#101923] border border-[#C5A15B]/30 space-y-4"
                  >
                    <h2 className="font-serif text-2xl font-semibold text-[#E2C989] pb-3 border-b border-[#C5A15B]/20">
                      Adicionar Local de Atuação
                    </h2>
                    <input
                      type="text"
                      required
                      placeholder="Nome do Local *"
                      value={newLocal.nome}
                      onChange={(e) => setNewLocal({ ...newLocal, nome: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                    <input
                      type="text"
                      required
                      placeholder="Cidade / Região *"
                      value={newLocal.cidade}
                      onChange={(e) => setNewLocal({ ...newLocal, cidade: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                    <input
                      type="text"
                      placeholder="Classificação (Ex.: Sede Oficial)"
                      value={newLocal.tipo}
                      onChange={(e) => setNewLocal({ ...newLocal, tipo: e.target.value })}
                      className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                    <textarea
                      rows={3}
                      placeholder="Descrição..."
                      value={newLocal.descricao}
                      onChange={(e) =>
                        setNewLocal({ ...newLocal, descricao: e.target.value })
                      }
                      className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                    />
                    <button
                      type="submit"
                      className="w-full inline-flex items-center justify-center gap-2 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#8B1E24] text-[#F3EFE5] border border-[#C5A15B]/50 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Adicionar Local</span>
                    </button>
                  </form>

                  <div className="lg:col-span-8 space-y-3">
                    {adminData.locais.map((l) => (
                      <div
                        key={l.id}
                        className="p-5 bg-[#101923] border border-[#C5A15B]/25 flex items-start justify-between gap-4"
                      >
                        <div>
                          <p className="text-xs text-[#C5A15B]">
                            {l.tipo} · {l.cidade}
                          </p>
                          <h3 className="font-serif text-xl text-[#F3EFE5]">{l.nome}</h3>
                          <p className="text-xs text-[#F3EFE5]/75 mt-1">{l.descricao}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => deleteLocal(l.id)}
                          className="p-1.5 text-[#F3EFE5]/60 hover:text-[#A6262D] cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: CRONOLOGIA */}
            {tab === 'cronologia' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                <form
                  onSubmit={addTimelineItem}
                  className="lg:col-span-4 p-6 bg-[#101923] border border-[#C5A15B]/30 space-y-4"
                >
                  <h2 className="font-serif text-2xl font-semibold text-[#E2C989] pb-3 border-b border-[#C5A15B]/20">
                    Novo Marco Histórico
                  </h2>
                  <input
                    type="text"
                    required
                    placeholder="Ano *"
                    value={newTimeline.ano}
                    onChange={(e) =>
                      setNewTimeline({ ...newTimeline, ano: e.target.value })
                    }
                    className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                  />
                  <input
                    type="text"
                    required
                    placeholder="Título *"
                    value={newTimeline.titulo}
                    onChange={(e) =>
                      setNewTimeline({ ...newTimeline, titulo: e.target.value })
                    }
                    className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                  />
                  <textarea
                    rows={3}
                    required
                    placeholder="Descrição histórica..."
                    value={newTimeline.descricao}
                    onChange={(e) =>
                      setNewTimeline({ ...newTimeline, descricao: e.target.value })
                    }
                    className="w-full px-3 py-2 text-sm bg-[#080B10] border border-[#C5A15B]/30 text-[#F3EFE5]"
                  />
                  <button
                    type="submit"
                    className="w-full py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#8B1E24] text-[#F3EFE5] border border-[#C5A15B]/50 cursor-pointer"
                  >
                    Adicionar Marco
                  </button>
                </form>

                <div className="lg:col-span-8 space-y-3">
                  {adminData.timeline.map((t) => (
                    <div
                      key={t.id}
                      className="p-5 bg-[#101923] border border-[#C5A15B]/25 flex items-start justify-between gap-4"
                    >
                      <div>
                        <span className="font-mono text-xs text-[#C5A15B] tabular-nums">
                          {t.ano}
                        </span>
                        <h3 className="font-serif text-xl text-[#F3EFE5]">{t.titulo}</h3>
                        <p className="text-xs text-[#F3EFE5]/75 mt-1">{t.descricao}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => deleteTimelineItem(t.id)}
                        className="p-1.5 text-[#F3EFE5]/60 hover:text-[#A6262D] cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 5: MENSAGENS */}
            {tab === 'mensagens' && (
              <div className="space-y-4">
                <h2 className="font-serif text-2xl font-semibold text-[#F3EFE5]">
                  Correspondências Recebidas ({adminData.mensagens.length})
                </h2>
                {adminData.mensagens.length === 0 ? (
                  <div className="p-10 bg-[#101923] border border-[#C5A15B]/25 text-center text-sm text-[#F3EFE5]/65">
                    Nenhuma mensagem registrada até o momento.
                  </div>
                ) : (
                  adminData.mensagens.map((m) => (
                    <div
                      key={m.id}
                      className="p-6 bg-[#101923] border border-[#C5A15B]/30 flex flex-col md:flex-row md:items-start justify-between gap-4"
                    >
                      <div className="space-y-2">
                        <div className="flex flex-wrap items-center gap-2 text-xs text-[#C5A15B]">
                          <Mail className="w-3.5 h-3.5" />
                          <span className="font-semibold uppercase tracking-wider">
                            {m.status}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="tabular-nums">
                            {new Date(m.dataEnvio).toLocaleDateString('pt-BR')}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{m.capituloOuInstituicao}</span>
                        </div>
                        <h3 className="font-serif text-2xl text-[#F3EFE5]">{m.assunto}</h3>
                        <p className="text-xs text-[#E2C989]">
                          Remetente: {m.nome} ({m.email})
                        </p>
                        <p className="text-sm text-[#F3EFE5]/85 leading-relaxed pt-1">
                          {m.mensagem}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {m.status !== 'Lida' && (
                          <button
                            type="button"
                            onClick={() => updateMensagemStatus(m.id, 'Lida')}
                            className="px-3 py-1.5 text-xs font-semibold bg-[#080B10] border border-[#C5A15B]/45 text-[#E2C989] hover:bg-[#C5A15B] hover:text-[#080B10] cursor-pointer"
                          >
                            Marcar Lida
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => deleteMensagem(m.id)}
                          aria-label="Excluir mensagem"
                          className="p-2 text-[#F3EFE5]/60 hover:text-[#A6262D] cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
