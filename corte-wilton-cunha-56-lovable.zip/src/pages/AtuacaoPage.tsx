import { ArrowRight, Shield } from 'lucide-react';
import { PortalData, PortalRoute } from '../types';
import { PORTAL_ASSETS } from '../constants/assets';
import { HeraldicImage, HeraldicRule } from '../components/HeraldicImage';

interface AtuacaoPageProps {
  data: PortalData;
  onNavigate: (route: PortalRoute) => void;
}

export function AtuacaoPage({ data, onNavigate }: AtuacaoPageProps) {
  const { config, atuacaoPilares } = data;

  const go = (route: PortalRoute) => {
    onNavigate(route);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div>
      {/* Masthead */}
      <section className="bg-[#101923] border-b border-[#C5A15B]/30 py-14 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-[0.2em] text-[#C5A15B] mb-3">
            <span>Finalidade & Propósito</span>
            <span aria-hidden="true">·</span>
            <span>{config.jurisdicao}</span>
          </div>
          <h1 className="font-serif text-4xl sm:text-5xl font-semibold text-[#F3EFE5] max-w-3xl">
            Como Atua a Corte Chevalier Wilton Cunha Nº 56
          </h1>
          <p className="mt-4 text-base sm:text-lg text-[#F3EFE5]/80 max-w-2xl leading-relaxed">
            A missão institucional da Corte em valorizar a honraria Chevalier e reconhecer os serviços prestados à Ordem DeMolay em Rondônia.
          </p>
        </div>
      </section>

      {/* Main Editorial Intro */}
      <section className="bg-[#F3EFE5] text-[#101923] py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8B1E24] mb-2">
                Propósito Institucional
              </p>
              <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#101923]">
                Valorização da Honraria Chevalier
              </h2>
              <HeraldicRule dark={false} />
              <p className="mt-6 text-[16px] text-[#101923]/85 leading-[1.8] max-w-2xl whitespace-pre-line">
                {config.atuacaoTexto}
              </p>
              <div className="mt-8">
                <button
                  type="button"
                  onClick={() => go('locais')}
                  className="inline-flex items-center gap-2 px-5 py-3 text-xs font-semibold uppercase tracking-wider bg-[#8B1E24] text-[#F3EFE5] border border-[#C5A15B]/50 hover:bg-[#A6262D] transition-colors cursor-pointer"
                >
                  <span>Conhecer Sede e Locais</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-5">
              <HeraldicImage
                src={PORTAL_ASSETS.CERIMONIA}
                alt={config.nome}
                aspectClassName="aspect-square"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Pillars Grid */}
      <section className="bg-[#080B10] text-[#F3EFE5] py-16 lg:py-24 border-t border-[#C5A15B]/25">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-12">
            <p className="text-xs uppercase tracking-[0.2em] text-[#C5A15B]">
              Finalidades
            </p>
            <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-semibold text-[#F3EFE5]">
              Pilares da Corte
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {atuacaoPilares.map((pilar, idx) => (
              <article
                key={pilar.id}
                className="p-8 bg-[#101923] border border-[#C5A15B]/30"
              >
                <div className="flex items-center justify-between pb-4 border-b border-[#C5A15B]/20">
                  <span className="font-mono text-xs text-[#C5A15B] tabular-nums">
                    {String(idx + 1).padStart(2, '0')} · {pilar.subtitulo}
                  </span>
                  <Shield className="w-4 h-4 text-[#8B1E24]" strokeWidth={1.5} />
                </div>
                <h3 className="mt-5 font-serif text-2xl sm:text-3xl font-semibold text-[#F3EFE5]">
                  {pilar.titulo}
                </h3>
                <p className="mt-3 text-sm sm:text-base text-[#F3EFE5]/80 leading-relaxed">
                  {pilar.descricao}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
