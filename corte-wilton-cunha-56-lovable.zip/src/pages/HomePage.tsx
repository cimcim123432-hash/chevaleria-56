import { ArrowRight, MapPin, Shield } from 'lucide-react';
import { motion } from 'motion/react';
import { PortalData, PortalRoute } from '../types';
import { PORTAL_ASSETS } from '../constants/assets';
import { HeraldicImage, HeraldicRule } from '../components/HeraldicImage';

interface HomePageProps {
  data: PortalData;
  onNavigate: (route: PortalRoute) => void;
}

export function HomePage({ data, onNavigate }: HomePageProps) {
  const { config, atuacaoPilares } = data;

  const go = (route: PortalRoute) => {
    onNavigate(route);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div>
      {/* Hero Monumental */}
      <section className="relative min-h-[560px] lg:min-h-[640px] flex items-center overflow-hidden bg-[#080B10] border-b border-[#C5A15B]/30">
        <img
          src={PORTAL_ASSETS.CERIMONIA}
          alt={config.nome}
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover object-center opacity-45"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-r from-[#080B10]/95 via-[#101923]/85 to-[#080B10]/70"
        />
        <div
          aria-hidden="true"
          className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#080B10] to-transparent"
        />

        <div className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              className="lg:col-span-8"
            >
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs uppercase tracking-[0.18em] text-[#E2C989] mb-5">
                <span>Ordem DeMolay</span>
                <span aria-hidden="true" className="text-[#8B1E24]">·</span>
                <span>{config.jurisdicao}</span>
                <span aria-hidden="true" className="text-[#8B1E24]">·</span>
                <span className="tabular-nums">Fundada em {config.fundacao}</span>
              </div>

              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-semibold text-[#F3EFE5] leading-[1.08] tracking-tight max-w-3xl">
                {config.nome}
              </h1>

              <div className="w-28 h-0.5 bg-gradient-to-r from-[#8B1E24] via-[#C5A15B] to-transparent my-6" />

              <p className="text-base sm:text-lg text-[#F3EFE5]/85 leading-relaxed max-w-2xl">
                {config.resumoInstitucional}
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-5">
                <button
                  type="button"
                  onClick={() => go('historia')}
                  className="inline-flex items-center gap-2.5 px-6 py-3 text-sm font-semibold tracking-wide bg-[#8B1E24] text-[#F3EFE5] border border-[#C5A15B]/50 hover:bg-[#A6262D] transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A15B]"
                >
                  <span>Conhecer a História da Corte</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => go('documentos')}
                  className="inline-flex items-center gap-2 px-5 py-3 text-sm font-medium text-[#E2C989] border border-[#C5A15B]/35 bg-[#101923]/75 hover:bg-[#101923] transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A15B]"
                >
                  <span>Ver Documentos Históricos</span>
                </button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="lg:col-span-4 flex justify-start lg:justify-end"
            >
              <div className="w-56 sm:w-64 lg:w-72 p-5 bg-[#101923]/90 border border-[#C5A15B]/45 flex flex-col items-center">
                <img
                  src={PORTAL_ASSETS.LOGO}
                  alt="Brasão da Corte Chevalier Wilton Cunha Nº 56"
                  referrerPolicy="no-referrer"
                  className="w-44 h-44 sm:w-48 sm:h-48 object-cover rounded-full border border-[#C5A15B]/50 bg-[#080B10]"
                />
                <div className="w-full pt-3 pb-1 text-center border-t border-[#C5A15B]/20 mt-4">
                  <p className="font-serif text-base text-[#E2C989] tracking-wide">
                    Corte Nº {config.numero} · Rondônia
                  </p>
                  <p className="text-[11px] uppercase tracking-widest text-[#F3EFE5]/60 mt-0.5">
                    {config.gestaoAtual}
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Operational Institutional Ribbon */}
      <section aria-label="Dados institucionais" className="bg-[#101923] border-b border-[#C5A15B]/25">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <dl className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-[#C5A15B]/20">
            <div className="py-5 sm:px-6 first:sm:pl-0">
              <dt className="text-xs uppercase tracking-widest text-[#C5A15B]">Fundação</dt>
              <dd className="mt-1 font-serif text-xl text-[#F3EFE5] tabular-nums">{config.fundacao}</dd>
            </div>
            <div className="py-5 sm:px-6">
              <dt className="text-xs uppercase tracking-widest text-[#C5A15B]">Jurisdição</dt>
              <dd className="mt-1 font-serif text-xl text-[#F3EFE5]">GCE-RO · Rondônia</dd>
            </div>
            <div className="py-5 sm:px-6">
              <dt className="text-xs uppercase tracking-widest text-[#C5A15B]">Patrono</dt>
              <dd className="mt-1 font-serif text-xl text-[#F3EFE5]">{config.patrono}</dd>
            </div>
            <div className="py-5 sm:px-6 last:sm:pr-0">
              <dt className="text-xs uppercase tracking-widest text-[#C5A15B]">Localização</dt>
              <dd className="mt-1 font-serif text-lg text-[#F3EFE5] leading-snug">
                Palácio Maçônico Euclides Sampaio Fróes
              </dd>
            </div>
          </dl>
        </div>
      </section>

      {/* Editorial Section on Archival Ivory */}
      <section className="bg-[#F3EFE5] text-[#101923] py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            <div className="lg:col-span-7">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8B1E24] mb-3">
                Finalidade & Tradição
              </p>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-[42px] font-semibold text-[#101923] leading-[1.15]">
                Valorizar a Honraria Chevalier e o Serviço à Ordem DeMolay
              </h2>

              <HeraldicRule dark={false} />

              <div className="mt-6 space-y-5 text-[16px] text-[#101923]/85 leading-[1.75] max-w-2xl whitespace-pre-line">
                <p className="first-letter:text-5xl first-letter:font-serif first-letter:font-bold first-letter:float-left first-letter:mr-3 first-letter:mt-1 first-letter:text-[#8B1E24]">
                  {config.historiaTexto}
                </p>
              </div>

              <blockquote className="my-8 py-6 border-y border-[#101923]/20 max-w-2xl">
                <p className="font-serif italic text-2xl text-[#101923] leading-snug">
                  “{config.lema}”
                </p>
                <footer className="mt-3 text-xs uppercase tracking-widest text-[#8B1E24] font-semibold">
                  Finalidade Institucional · Corte Nº {config.numero}
                </footer>
              </blockquote>

              <div className="p-6 bg-[#101923] text-[#F3EFE5] border border-[#C5A15B]/35 max-w-2xl">
                <p className="text-xs uppercase tracking-widest text-[#C5A15B]">
                  Patrono da Corte
                </p>
                <h3 className="mt-2 font-serif text-2xl text-[#F3EFE5]">
                  {config.patrono}
                </h3>
                <p className="mt-2.5 text-sm text-[#F3EFE5]/80 leading-relaxed">
                  {config.patronoTexto}
                </p>
                <button
                  type="button"
                  onClick={() => go('historia')}
                  className="mt-4 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#E2C989] hover:text-[#F3EFE5] transition-colors cursor-pointer"
                >
                  <span>Ler história completa</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-5">
              <HeraldicImage
                src={PORTAL_ASSETS.CERIMONIA}
                alt={config.nome}
                aspectClassName="aspect-square"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Como Atuamos Preview */}
      <section className="bg-[#080B10] text-[#F3EFE5] py-16 lg:py-24 border-t border-[#C5A15B]/25">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#C5A15B]/25">
            <div>
              <p className="text-xs uppercase tracking-[0.2em] text-[#C5A15B]">
                Atuação Institucional
              </p>
              <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-semibold text-[#F3EFE5]">
                Como Atuamos em Rondônia
              </h2>
            </div>
            <button
              type="button"
              onClick={() => go('atuacao')}
              className="inline-flex items-center gap-2 text-sm font-medium text-[#E2C989] hover:text-[#F3EFE5] transition-colors cursor-pointer self-start sm:self-auto"
            >
              <span>Ver detalhes da atuação</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
            {atuacaoPilares.map((pilar, idx) => (
              <div
                key={pilar.id}
                className="p-7 bg-[#101923] border border-[#C5A15B]/25 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between pb-3 border-b border-[#C5A15B]/15">
                    <span className="font-mono text-xs text-[#C5A15B] tabular-nums">
                      {String(idx + 1).padStart(2, '0')} · {pilar.subtitulo}
                    </span>
                    <Shield className="w-4 h-4 text-[#8B1E24]" strokeWidth={1.5} />
                  </div>
                  <h3 className="mt-4 font-serif text-2xl font-semibold text-[#F3EFE5]">
                    {pilar.titulo}
                  </h3>
                  <p className="mt-2.5 text-sm text-[#F3EFE5]/80 leading-relaxed">
                    {pilar.descricao}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Location Showcase */}
      <section className="bg-[#101923] text-[#F3EFE5] py-16 lg:py-24 border-t border-[#C5A15B]/25">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            <div className="lg:col-span-7">
              <HeraldicImage
                src={PORTAL_ASSETS.LOCAL}
                alt="Palácio Maçônico Euclides Sampaio Fróes"
                aspectClassName="aspect-[16/10] lg:h-full"
              />
            </div>

            <div className="lg:col-span-5 flex flex-col justify-between p-8 bg-[#080B10] border border-[#C5A15B]/30">
              <div>
                <p className="text-xs uppercase tracking-[0.2em] text-[#C5A15B]">
                  Localização
                </p>
                <h2 className="mt-3 font-serif text-3xl font-semibold text-[#F3EFE5] leading-tight">
                  Palácio Maçônico Euclides Sampaio Fróes
                </h2>
                <p className="mt-4 text-sm sm:text-base text-[#F3EFE5]/80 leading-relaxed">
                  Sede institucional em Porto Velho, Estado de Rondônia, onde a Corte Chevalier Wilton Cunha Nº 56 está estabelecida sob jurisdição do Grande Capítulo do Estado de Rondônia (GCE-RO).
                </p>

                <dl className="mt-6 pt-6 border-t border-[#C5A15B]/20 space-y-3 text-sm">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-[#C5A15B] shrink-0 mt-0.5" />
                    <div>
                      <dt className="text-xs text-[#F3EFE5]/55">Endereço</dt>
                      <dd className="text-[#F3EFE5]">{config.endereco}</dd>
                    </div>
                  </div>
                </dl>
              </div>

              <div className="mt-8 pt-6 border-t border-[#C5A15B]/20">
                <button
                  type="button"
                  onClick={() => go('locais')}
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-semibold bg-[#101923] text-[#E2C989] border border-[#C5A15B]/45 hover:bg-[#8B1E24] hover:border-[#8B1E24] hover:text-[#F3EFE5] transition-colors cursor-pointer"
                >
                  <span>Explorar Locais e Contato</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
