import { useState } from 'react';
import { X } from 'lucide-react';
import { PortalData } from '../types';
import { PORTAL_ASSETS } from '../constants/assets';
import { HeraldicRule } from '../components/HeraldicImage';

interface HistoriaPageProps {
  data: PortalData;
}

const SITE_PHOTOS = [
  PORTAL_ASSETS.TEMPLO_GRUPO,
  PORTAL_ASSETS.PLACA_MOLAY,
  PORTAL_ASSETS.MONUMENTO_1,
  PORTAL_ASSETS.MONUMENTO_2,
];

export function HistoriaPage({ data }: HistoriaPageProps) {
  const { config, timeline } = data;
  const [zoomPhoto, setZoomPhoto] = useState<string | null>(null);

  return (
    <div>
      {/* Page Masthead */}
      <section className="bg-[#101923] border-b border-[#C5A15B]/30 py-14 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-[0.2em] text-[#C5A15B] mb-3">
            <span>Arquivo Institucional</span>
            <span aria-hidden="true">·</span>
            <span>{config.jurisdicao}</span>
          </div>
          <h1 className="font-serif text-4xl sm:text-5xl font-semibold text-[#F3EFE5] max-w-3xl">
            História e Patrono
          </h1>
          <p className="mt-4 text-base sm:text-lg text-[#F3EFE5]/80 max-w-2xl leading-relaxed">
            A trajetória da Corte Chevalier Wilton Cunha Nº 56 desde sua fundação em 14 de abril de 2004 em Rondônia.
          </p>
        </div>
      </section>

      {/* Editorial Essay & Patrono */}
      <section className="bg-[#F3EFE5] text-[#101923] py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            <article className="lg:col-span-8 space-y-10">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#8B1E24] mb-2">
                  Fundação & Jurisdição
                </p>
                <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#101923]">
                  Corte Chevalier Wilton Cunha Nº 56
                </h2>
                <HeraldicRule dark={false} />
              </div>

              <div className="space-y-5 text-[16px] text-[#101923]/85 leading-[1.8] max-w-prose whitespace-pre-line">
                <p className="first-letter:text-5xl first-letter:font-serif first-letter:font-bold first-letter:float-left first-letter:mr-3 first-letter:mt-1 first-letter:text-[#8B1E24]">
                  {config.historiaTexto}
                </p>
              </div>

              <div className="pt-4">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#8B1E24] mb-2">
                  Patrono Institucional
                </p>
                <h2 className="font-serif text-3xl font-semibold text-[#101923] mb-6">
                  {config.patrono}
                </h2>

                <div className="space-y-5 text-[16px] text-[#101923]/85 leading-[1.8] max-w-prose whitespace-pre-line">
                  <p>{config.patronoTexto}</p>
                </div>

                <div className="mt-8 p-6 bg-[#EBE5D6] border border-[#101923]/15 max-w-prose">
                  <p className="text-xs uppercase tracking-widest text-[#8B1E24] font-semibold">
                    Finalidade da Corte
                  </p>
                  <p className="mt-2 text-sm text-[#101923]/85 leading-relaxed">
                    Valorizar a honraria Chevalier e reconhecer a dedicação e os serviços prestados à Ordem DeMolay.
                  </p>
                </div>
              </div>
            </article>

            {/* Margin Sidebar */}
            <aside className="lg:col-span-4 space-y-6">
              <div className="p-6 bg-[#EBE5D6] border border-[#101923]/15">
                <p className="text-xs font-semibold uppercase tracking-widest text-[#8B1E24] pb-3 border-b border-[#101923]/15">
                  Dados Institucionais
                </p>
                <dl className="divide-y divide-[#101923]/12 text-sm">
                  <div className="py-3">
                    <dt className="text-xs text-[#101923]/60">Denominação Oficial</dt>
                    <dd className="font-serif text-lg font-semibold text-[#101923] mt-0.5">
                      {config.nome}
                    </dd>
                  </div>
                  <div className="py-3">
                    <dt className="text-xs text-[#101923]/60">Número de Registro</dt>
                    <dd className="font-mono text-sm text-[#101923] tabular-nums mt-0.5">
                      CORTE Nº {config.numero}
                    </dd>
                  </div>
                  <div className="py-3">
                    <dt className="text-xs text-[#101923]/60">Fundação Informada</dt>
                    <dd className="text-[#101923] tabular-nums mt-0.5">{config.fundacao}</dd>
                  </div>
                  <div className="py-3">
                    <dt className="text-xs text-[#101923]/60">Jurisdição</dt>
                    <dd className="text-[#101923] mt-0.5">{config.jurisdicao}</dd>
                  </div>
                  <div className="py-3">
                    <dt className="text-xs text-[#101923]/60">Sede</dt>
                    <dd className="text-[#101923] mt-0.5">{config.endereco}</dd>
                  </div>
                  <div className="py-3">
                    <dt className="text-xs text-[#101923]/60">Patrono</dt>
                    <dd className="text-[#101923] mt-0.5">{config.patrono}</dd>
                  </div>
                </dl>
              </div>
            </aside>
          </div>

          {/* Imagens inseridas sem descrição */}
          <div className="mt-14 pt-12 border-t border-[#101923]/15 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {SITE_PHOTOS.map((src, idx) => (
              <div
                key={src}
                onClick={() => setZoomPhoto(src)}
                className="cursor-pointer bg-[#101923] border border-[#C5A15B]/35 p-2 aspect-[4/3] overflow-hidden"
              >
                <img
                  src={src}
                  alt={`Imagem ${idx + 1}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover hover:scale-[1.02] transition-transform duration-300"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Historical Timeline */}
      <section className="bg-[#080B10] text-[#F3EFE5] py-16 lg:py-24 border-t border-[#C5A15B]/25">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-12">
            <p className="text-xs uppercase tracking-[0.2em] text-[#C5A15B]">
              Cronologia Oficial
            </p>
            <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-semibold text-[#F3EFE5]">
              Marcos Históricos da Corte Nº 56
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {timeline.map((item, idx) => (
              <div
                key={item.id}
                className="p-6 bg-[#101923] border border-[#C5A15B]/25 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between pb-4 border-b border-[#C5A15B]/20">
                    <span className="font-mono text-xs text-[#C5A15B] tabular-nums">
                      {String(idx + 1).padStart(2, '0')} / MARCO
                    </span>
                    <span className="font-serif text-2xl font-semibold text-[#E2C989] tabular-nums">
                      {item.ano}
                    </span>
                  </div>
                  <h3 className="mt-4 font-serif text-2xl font-semibold text-[#F3EFE5]">
                    {item.titulo}
                  </h3>
                  <p className="mt-3 text-sm text-[#F3EFE5]/80 leading-relaxed">
                    {item.descricao}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {zoomPhoto && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#080B10]/90 backdrop-blur-sm"
          onClick={() => setZoomPhoto(null)}
        >
          <div
            className="w-full max-w-4xl bg-[#101923] border border-[#C5A15B]/60 p-4 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setZoomPhoto(null)}
              aria-label="Fechar imagem"
              className="absolute top-3 right-3 p-2 bg-[#080B10] text-[#F3EFE5] border border-[#C5A15B]/40 hover:text-[#E2C989] cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={zoomPhoto}
              alt="Visualização ampliada"
              referrerPolicy="no-referrer"
              className="w-full max-h-[82vh] object-contain bg-[#080B10]"
            />
          </div>
        </div>
      )}
    </div>
  );
}
