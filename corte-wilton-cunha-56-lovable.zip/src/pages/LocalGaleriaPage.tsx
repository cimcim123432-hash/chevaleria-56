import { FormEvent, useState } from 'react';
import { CheckCircle2, MapPin, Send } from 'lucide-react';
import { PortalData } from '../types';
import { PORTAL_ASSETS } from '../constants/assets';
import { HeraldicImage } from '../components/HeraldicImage';
import { submitContactMessage } from '../services/portalService';

interface LocalGaleriaPageProps {
  data: PortalData;
}

export function LocalGaleriaPage({ data }: LocalGaleriaPageProps) {
  const { config, locais } = data;

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [capitulo, setCapitulo] = useState('');
  const [assunto, setAssunto] = useState('');
  const [mensagem, setMensagem] = useState('');
  const [sending, setSending] = useState(false);
  const [sentOk, setSentOk] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleContact = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSentOk(false);
    setSending(true);
    try {
      const result = await submitContactMessage({
        nome,
        email,
        capituloOuInstituicao: capitulo,
        assunto,
        mensagem,
      });
      if (!result.ok) {
        setErrorMsg(result.error || 'Não foi possível enviar sua mensagem.');
      } else {
        setSentOk(true);
        setNome('');
        setEmail('');
        setCapitulo('');
        setAssunto('');
        setMensagem('');
      }
    } catch {
      setErrorMsg('Falha de comunicação com o servidor.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div>
      {/* Header */}
      <section className="bg-[#101923] border-b border-[#C5A15B]/30 py-14 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-[0.2em] text-[#C5A15B] mb-3">
            <span>Porto Velho · Rondônia</span>
            <span aria-hidden="true">·</span>
            <span>{config.jurisdicao}</span>
          </div>
          <h1 className="font-serif text-4xl sm:text-5xl font-semibold text-[#F3EFE5] max-w-3xl">
            Locais & Sede Oficial
          </h1>
          <p className="mt-4 text-base sm:text-lg text-[#F3EFE5]/80 max-w-2xl leading-relaxed">
            Palácio Maçônico Euclides Sampaio Fróes, em Porto Velho, Rondônia.
          </p>
        </div>
      </section>

      {/* Main Location Spotlight */}
      <section className="bg-[#F3EFE5] text-[#101923] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7">
              <HeraldicImage
                src={PORTAL_ASSETS.LOCAL}
                alt="Palácio Maçônico Euclides Sampaio Fróes"
                aspectClassName="aspect-[16/10]"
              />
            </div>
            <div className="lg:col-span-5 space-y-5">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8B1E24]">
                Sede em Rondônia
              </p>
              <h2 className="font-serif text-3xl font-semibold text-[#101923]">
                Palácio Maçônico Euclides Sampaio Fróes
              </h2>
              <p className="text-sm sm:text-base text-[#101923]/80 leading-relaxed">
                Localização oficial vinculada às atividades da Corte Chevalier Wilton Cunha Nº 56 em Porto Velho, sob jurisdição do Grande Capítulo do Estado de Rondônia (GCE-RO).
              </p>
              <div className="p-5 bg-[#EBE5D6] border border-[#101923]/15 space-y-2 text-sm">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-[#8B1E24] shrink-0 mt-0.5" />
                  <span className="font-medium text-[#101923]">{config.endereco}</span>
                </div>
              </div>
            </div>
          </div>

          {locais.length > 0 && (
            <div className="mt-14 pt-12 border-t border-[#101923]/15">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#8B1E24] mb-6">
                Locais Registrados
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {locais.map((loc) => (
                  <div
                    key={loc.id}
                    className="p-6 bg-[#EBE5D6] border border-[#101923]/15"
                  >
                    <p className="text-xs uppercase tracking-wider text-[#8B1E24] font-semibold">
                      {loc.tipo}
                    </p>
                    <h3 className="mt-2 font-serif text-2xl font-semibold text-[#101923]">
                      {loc.nome}
                    </h3>
                    <p className="mt-1 text-xs font-medium text-[#101923]/70">{loc.cidade}</p>
                    {loc.descricao && (
                      <p className="mt-3 text-sm text-[#101923]/80 leading-relaxed">
                        {loc.descricao}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Contact Form */}
      <section className="bg-[#101923] text-[#F3EFE5] py-16 lg:py-24 border-t border-[#C5A15B]/25">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <p className="text-xs uppercase tracking-[0.2em] text-[#C5A15B]">
              Comunicação Oficial
            </p>
            <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-semibold text-[#F3EFE5]">
              Contato com a Administração
            </h2>
          </div>

          <form
            onSubmit={handleContact}
            className="p-6 sm:p-8 bg-[#080B10] border border-[#C5A15B]/35 space-y-5"
          >
            {sentOk && (
              <div className="p-4 bg-[#101923] border border-[#C5A15B] flex items-center gap-3 text-sm text-[#E2C989]">
                <CheckCircle2 className="w-5 h-5 text-[#C5A15B] shrink-0" />
                <span>
                  Mensagem registrada com sucesso.
                </span>
              </div>
            )}

            {errorMsg && (
              <div className="p-4 bg-[#8B1E24]/25 border border-[#8B1E24] text-sm text-[#F3EFE5]">
                {errorMsg}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-2">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  required
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-[#101923] border border-[#C5A15B]/30 text-[#F3EFE5] focus:outline-none focus:border-[#C5A15B]"
                  placeholder="Seu nome"
                />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-2">
                  E-mail de Retorno *
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-[#101923] border border-[#C5A15B]/30 text-[#F3EFE5] focus:outline-none focus:border-[#C5A15B]"
                  placeholder="seu@email.com.br"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-2">
                  Capítulo, Loja ou Instituição
                </label>
                <input
                  type="text"
                  value={capitulo}
                  onChange={(e) => setCapitulo(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-[#101923] border border-[#C5A15B]/30 text-[#F3EFE5] focus:outline-none focus:border-[#C5A15B]"
                  placeholder="Opcional"
                />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-2">
                  Assunto
                </label>
                <input
                  type="text"
                  value={assunto}
                  onChange={(e) => setAssunto(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-[#101923] border border-[#C5A15B]/30 text-[#F3EFE5] focus:outline-none focus:border-[#C5A15B]"
                  placeholder="Assunto da mensagem"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-[#C5A15B] mb-2">
                Mensagem *
              </label>
              <textarea
                required
                rows={4}
                value={mensagem}
                onChange={(e) => setMensagem(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-[#101923] border border-[#C5A15B]/30 text-[#F3EFE5] focus:outline-none focus:border-[#C5A15B]"
                placeholder="Escreva sua mensagem..."
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={sending}
                className="inline-flex items-center gap-2 px-6 py-3 text-xs font-semibold uppercase tracking-wider bg-[#8B1E24] text-[#F3EFE5] border border-[#C5A15B]/50 hover:bg-[#A6262D] disabled:opacity-60 transition-colors cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{sending ? 'Enviando...' : 'Enviar Mensagem'}</span>
              </button>
            </div>
          </form>
        </div>
      </section>
    </div>
  );
}
