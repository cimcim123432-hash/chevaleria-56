import { useState } from 'react';
import { FileText, ZoomIn, X } from 'lucide-react';
import { DocumentoHistorico, PortalData } from '../types';
import { HeraldicRule } from '../components/HeraldicImage';

interface DocumentosPageProps {
  data: PortalData;
}

export function DocumentosPage({ data }: DocumentosPageProps) {
  const { config, documentos } = data;
  const [selectedDoc, setSelectedDoc] = useState<DocumentoHistorico | null>(null);

  return (
    <div>
      {/* Masthead */}
      <section className="bg-[#101923] border-b border-[#C5A15B]/30 py-14 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-[0.2em] text-[#C5A15B] mb-3">
            <span>Acervo Documental</span>
            <span aria-hidden="true">·</span>
            <span>{config.jurisdicao}</span>
          </div>
          <h1 className="font-serif text-4xl sm:text-5xl font-semibold text-[#F3EFE5] max-w-3xl">
            Documentos Históricos e Cartas Oficiais
          </h1>
          <p className="mt-4 text-base sm:text-lg text-[#F3EFE5]/80 max-w-2xl leading-relaxed">
            Registros originais, cartas constitutivas e documentos históricos que comprovam e preservam a fundação e a trajetória da Corte Chevalier Wilton Cunha Nº 56.
          </p>
        </div>
      </section>

      {/* Documents List */}
      <section className="bg-[#F3EFE5] text-[#101923] py-16 lg:py-24 min-h-[540px]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          {documentos.length === 0 ? (
            <div className="p-12 text-center bg-[#EBE5D6] border border-[#101923]/15">
              <FileText className="w-8 h-8 text-[#8B1E24] mx-auto mb-3" strokeWidth={1.5} />
              <p className="font-serif text-2xl text-[#101923]">
                Nenhum documento catalogado no momento.
              </p>
            </div>
          ) : (
            documentos.map((doc, idx) => (
              <article
                key={doc.id}
                className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start pb-14 border-b border-[#101923]/15 last:border-b-0 last:pb-0"
              >
                {/* Document Image Frame */}
                <div className="lg:col-span-5">
                  <div
                    onClick={() => setSelectedDoc(doc)}
                    className="group relative bg-[#101923] border border-[#C5A15B]/50 p-3 cursor-pointer"
                  >
                    <img
                      src={doc.imagemUrl}
                      alt={doc.titulo}
                      referrerPolicy="no-referrer"
                      className="w-full h-auto object-contain bg-[#080B10]"
                    />
                    <div className="mt-3 pt-2.5 border-t border-[#C5A15B]/25 flex items-center justify-between text-xs text-[#E2C989]">
                      <span className="font-mono tabular-nums">
                        DOC. {String(idx + 1).padStart(2, '0')}
                      </span>
                      <span className="inline-flex items-center gap-1.5 font-medium group-hover:underline">
                        <ZoomIn className="w-3.5 h-3.5" />
                        Ampliar Documento
                      </span>
                    </div>
                  </div>
                </div>

                {/* Archival Catalog Metadata & Details */}
                <div className="lg:col-span-7 space-y-5">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-[0.18em] text-[#8B1E24] font-semibold">
                      <span>{doc.tipo}</span>
                      {doc.dataDocumento && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="tabular-nums">{doc.dataDocumento}</span>
                        </>
                      )}
                    </div>
                    <h2 className="mt-2 font-serif text-3xl sm:text-4xl font-semibold text-[#101923] leading-tight">
                      {doc.titulo}
                    </h2>
                    <HeraldicRule dark={false} />
                  </div>

                  <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4 border-y border-[#101923]/15 text-sm">
                    <div>
                      <dt className="text-xs text-[#101923]/60">Órgão Emissor</dt>
                      <dd className="font-semibold text-[#101923] mt-0.5">
                        {doc.orgaoEmissor}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs text-[#101923]/60">Data de Expedição</dt>
                      <dd className="font-semibold text-[#101923] mt-0.5 tabular-nums">
                        {doc.dataDocumento || 'Não informada'}
                      </dd>
                    </div>
                  </dl>

                  <p className="text-[16px] text-[#101923]/85 leading-[1.8]">
                    {doc.descricao}
                  </p>

                  {doc.detalhes && (
                    <div className="p-5 bg-[#EBE5D6] border border-[#101923]/15 text-sm text-[#101923]/85 leading-relaxed">
                      <p className="text-xs uppercase tracking-widest text-[#8B1E24] font-semibold mb-2">
                        Registro e Transcrição
                      </p>
                      <p>{doc.detalhes}</p>
                    </div>
                  )}

                  <div>
                    <button
                      type="button"
                      onClick={() => setSelectedDoc(doc)}
                      className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#101923] text-[#E2C989] border border-[#C5A15B]/50 hover:bg-[#8B1E24] hover:text-[#F3EFE5] transition-colors cursor-pointer"
                    >
                      <ZoomIn className="w-3.5 h-3.5" />
                      <span>Visualizar Documento em Alta Resolução</span>
                    </button>
                  </div>
                </div>
              </article>
            ))
          )}
        </div>
      </section>

      {/* High-Res Lightbox */}
      {selectedDoc && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="doc-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#080B10]/90 backdrop-blur-sm"
          onClick={() => setSelectedDoc(null)}
        >
          <div
            className="w-full max-w-4xl bg-[#101923] border border-[#C5A15B]/60 p-5 sm:p-6 relative max-h-[92vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setSelectedDoc(null)}
              aria-label="Fechar documento"
              className="absolute top-4 right-4 p-2 bg-[#080B10] text-[#F3EFE5] border border-[#C5A15B]/40 hover:text-[#E2C989] cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <img
              src={selectedDoc.imagemUrl}
              alt={selectedDoc.titulo}
              referrerPolicy="no-referrer"
              className="w-full max-h-[74vh] object-contain bg-[#080B10]"
            />

            <div className="mt-4 pt-4 border-t border-[#C5A15B]/20">
              <p className="text-xs text-[#C5A15B] tabular-nums">
                {selectedDoc.tipo} · {selectedDoc.dataDocumento} · {selectedDoc.orgaoEmissor}
              </p>
              <h3 id="doc-modal-title" className="mt-1 font-serif text-2xl text-[#F3EFE5]">
                {selectedDoc.titulo}
              </h3>
              <p className="mt-1.5 text-sm text-[#F3EFE5]/80">{selectedDoc.descricao}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
