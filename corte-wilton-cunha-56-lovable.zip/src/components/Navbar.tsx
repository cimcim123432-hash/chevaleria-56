import { useState } from 'react';
import { Menu, X, Lock } from 'lucide-react';
import { PortalRoute } from '../types';

interface NavbarProps {
  currentRoute: PortalRoute;
  onNavigate: (route: PortalRoute) => void;
  isAdminAuthenticated: boolean;
}

const NAV_ITEMS: { route: PortalRoute; label: string }[] = [
  { route: 'inicio', label: 'Início' },
  { route: 'historia', label: 'História' },
  { route: 'atuacao', label: 'Como Atuamos' },
  { route: 'documentos', label: 'Documentos' },
  { route: 'locais', label: 'Locais & Sede' },
];

export function Navbar({
  currentRoute,
  onNavigate,
  isAdminAuthenticated,
}: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleSelect = (route: PortalRoute) => {
    onNavigate(route);
    setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#080B10]/95 backdrop-blur-md border-b border-[#C5A15B]/25">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand wordmark only */}
        <button
          type="button"
          onClick={() => handleSelect('inicio')}
          className="font-serif text-lg sm:text-xl font-semibold tracking-wide text-[#F3EFE5] hover:text-[#E2C989] transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A15B]"
        >
          Corte Wilton Cunha Nº 56
        </button>

        {/* Zone 2: 5 concise single-line nav links */}
        <nav
          aria-label="Navegação principal"
          className="hidden lg:flex items-center gap-7"
        >
          {NAV_ITEMS.map((item) => {
            const active = currentRoute === item.route;
            return (
              <button
                key={item.route}
                type="button"
                onClick={() => handleSelect(item.route)}
                className={`relative py-2 text-sm font-medium tracking-wide transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A15B] ${
                  active
                    ? 'text-[#E2C989]'
                    : 'text-[#F3EFE5]/80 hover:text-[#F3EFE5]'
                }`}
              >
                {item.label}
                {active && (
                  <span
                    aria-hidden="true"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-[#8B1E24] via-[#C5A15B] to-[#8B1E24]"
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary action + Mobile trigger */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => handleSelect('admin')}
            className={`hidden sm:inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold tracking-wider uppercase border transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A15B] ${
              currentRoute === 'admin'
                ? 'bg-[#C5A15B] text-[#080B10] border-[#C5A15B]'
                : 'bg-[#101923] text-[#E2C989] border-[#C5A15B]/45 hover:bg-[#8B1E24] hover:border-[#8B1E24] hover:text-[#F3EFE5]'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>{isAdminAuthenticated ? 'Administração · CAA' : 'Administração'}</span>
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? 'Fechar menu' : 'Abrir menu'}
            aria-expanded={mobileOpen}
            className="lg:hidden p-2.5 text-[#F3EFE5] hover:text-[#E2C989] border border-[#C5A15B]/30 bg-[#101923] cursor-pointer"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="lg:hidden bg-[#080B10] border-b border-[#C5A15B]/25 px-4 py-4">
          <nav className="flex flex-col gap-1" aria-label="Navegação móvel">
            {NAV_ITEMS.map((item) => {
              const active = currentRoute === item.route;
              return (
                <button
                  key={item.route}
                  type="button"
                  onClick={() => handleSelect(item.route)}
                  className={`w-full text-left px-3 py-3 text-sm font-medium border-b border-[#C5A15B]/10 transition-colors cursor-pointer ${
                    active ? 'text-[#E2C989] bg-[#101923]' : 'text-[#F3EFE5]/85'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
            <button
              type="button"
              onClick={() => handleSelect('admin')}
              className="mt-3 w-full flex items-center justify-center gap-2 px-4 py-3 text-xs font-semibold uppercase tracking-wider bg-[#8B1E24] text-[#F3EFE5] border border-[#C5A15B]/40 cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Administração</span>
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
