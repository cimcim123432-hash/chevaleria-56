import { useState } from 'react';
import { Shield } from 'lucide-react';

interface HeraldicImageProps {
  src: string;
  alt: string;
  className?: string;
  aspectClassName?: string;
}

export function HeraldicImage({
  src,
  alt,
  className = '',
  aspectClassName = '',
}: HeraldicImageProps) {
  const [failed, setFailed] = useState(false);

  return (
    <div
      className={`relative overflow-hidden bg-[#101923] border border-[#C5A15B]/25 ${aspectClassName}`}
    >
      {!failed ? (
        <img
          src={src}
          alt={alt}
          referrerPolicy="no-referrer"
          onError={() => setFailed(true)}
          className={`w-full h-full object-cover ${className}`}
        />
      ) : (
        <div className="w-full h-full min-h-[220px] flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#101923] via-[#080B10] to-[#2B0C10]">
          <Shield className="w-10 h-10 text-[#C5A15B] mb-3" strokeWidth={1.25} />
          <span className="font-serif text-base text-[#F3EFE5] max-w-xs">{alt}</span>
        </div>
      )}
    </div>
  );
}

export function HeraldicRule({ dark = true }: { dark?: boolean }) {
  return (
    <div className="flex items-center gap-4 my-2" aria-hidden="true">
      <div
        className={`h-px flex-1 ${
          dark ? 'bg-[#C5A15B]/25' : 'bg-[#101923]/15'
        }`}
      />
      <div className="flex items-center gap-1.5">
        <span className="w-1.5 h-1.5 rotate-45 bg-[#8B1E24] block" />
        <span className="w-2 h-2 rotate-45 border border-[#C5A15B] block" />
        <span className="w-1.5 h-1.5 rotate-45 bg-[#8B1E24] block" />
      </div>
      <div
        className={`h-px flex-1 ${
          dark ? 'bg-[#C5A15B]/25' : 'bg-[#101923]/15'
        }`}
      />
    </div>
  );
}
