import { PortalConfig, PortalRoute } from '../types';
import { PORTAL_ASSETS } from '../constants/assets';

interface FooterProps {
  config: PortalConfig;
  onNavigate: (route: PortalRoute) => void;
}

export function Footer({ config, onNavigate }: FooterProps) {
  const go = (route: PortalRoute) => {
    onNavigate(route);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#080B10] border-t border-[#C5A15B]/30 text-[#F3EFE5]">
      <div className="h-1 w-full bg-gradient-to-r from-[#101923] via-[#8B1E24] to-[#C5A15B]" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-[#C5A15B]/15">
          <div className="md:col-span-5 flex items-start gap-5">
            <img
              src={PORTAL_ASSETS.LOGO}
              alt="Logo original da Corte Chevalier Wilton Cunha Nº 56"
              referrerPolicy="no-referrer"
              className="w-16 h-16 object-cover rounded-full border border-[#C5A15B]/50 shrink-0 bg-[#080B10]"
            />
            <div>
              <h2 className="font-serif text-xl font-semibold text-[#E2C989]">
                {config.nome}
              </h2>
              <p className="mt-1.5 text-sm text-[#F3EFE5]/75 leading-relaxed">
                Vinculada à Ordem DeMolay sob jurisdição do{' '}
                <strong className="font-medium text-[#F3EFE5]">
                  {config.jurisdicao}
                </strong>
                .
              </p>
              <p className="mt-2 text-xs text-[#C5A15B] tabular-nums">
                Fundada em {config.fundacao} · Patrono: {config.patrono}
              </p>
            </div>
          </div>

          <div className="md:col-span-3">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-[#C5A15B] mb-4">
              Navegação do Portal
            </h3>
            <ul className="space-y-2.5 text-sm text-[#F3EFE5]/80">
              <li>
                <button
                  type="button"
                  onClick={() => go('inicio')}
                  className="hover:text-[#E2C989] transition-colors cursor-pointer"
                >
                  Página Inicial
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => go('historia')}
                  className="hover:text-[#E2C989] transition-colors cursor-pointer"
                >
                  História & Patrono
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => go('atuacao')}
                  className="hover:text-[#E2C989] transition-colors cursor-pointer"
                >
                  Como Atuamos
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => go('documentos')}
                  className="hover:text-[#E2C989] transition-colors cursor-pointer"
                >
                  Documentos Históricos
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => go('locais')}
                  className="hover:text-[#E2C989] transition-colors cursor-pointer"
                >
                  Locais & Sede Oficial
                </button>
              </li>
            </ul>
          </div>

          <div className="md:col-span-4">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-[#C5A15B] mb-4">
              Sede & Contato
            </h3>
            <dl className="space-y-2.5 text-sm text-[#F3EFE5]/80">
              <div>
                <dt className="text-xs text-[#F3EFE5]/50">Localização</dt>
                <dd>{config.endereco}</dd>
              </div>
              <div>
                <dt className="text-xs text-[#F3EFE5]/50">E-mail Oficial</dt>
                <dd>{config.emailContato}</dd>
              </div>
            </dl>
          </div>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-[#F3EFE5]/55">
          <p>
            © {new Date().getFullYear()} {config.nome} · {config.cidadeSede}. Todos os direitos institucionais reservados.
          </p>
          <button
            type="button"
            onClick={() => go('admin')}
            className="text-[#C5A15B] hover:text-[#E2C989] transition-colors cursor-pointer"
          >
            Administração (CAA)
          </button>
        </div>
      </div>
    </footer>
  );
}
