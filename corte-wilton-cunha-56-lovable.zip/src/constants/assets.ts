export const PORTAL_ASSETS = {
  LOGO: '/assets/aistudio/logo_wilton_cunha_90fec92e.jpg',
  LOCAL: '/assets/aistudio/local_977dc478.jpg',
  CERIMONIA: '/assets/aistudio/wilton_cunha_1b7e0e69.png',
  CARTA_CONSTITUTIVA: '/assets/aistudio/WhatsApp_Image_2026-11-22_at_00.30.12_32807d4f.jpeg',
  TEMPLO_GRUPO: '/assets/aistudio/WhatsApp_Image_2026-11-22_at_00.57.29_ccb04431.jpeg',
  PLACA_MOLAY: '/assets/aistudio/WhatsApp_Image_2026-11-22_at_00.52.02__2__24bb855b.jpeg',
  MONUMENTO_1: '/assets/aistudio/WhatsApp_Image_2026-11-22_at_00.52.02__1__0586473e.jpeg',
  MONUMENTO_2: '/assets/aistudio/WhatsApp_Image_2026-11-22_at_00.52.02_98923518.jpeg',
} as const;
