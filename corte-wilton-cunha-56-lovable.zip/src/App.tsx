import { useCallback, useEffect, useState } from 'react';
import { PortalData, PortalRoute } from './types';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { HistoriaPage } from './pages/HistoriaPage';
import { AtuacaoPage } from './pages/AtuacaoPage';
import { DocumentosPage } from './pages/DocumentosPage';
import { LocalGaleriaPage } from './pages/LocalGaleriaPage';
import { AdminPage } from './pages/AdminPage';

import { fetchPublicPortalData } from './services/portalService';

const VALID_ROUTES: PortalRoute[] = [
  'inicio',
  'historia',
  'atuacao',
  'documentos',
  'locais',
  'admin',
];

function getInitialRoute(): PortalRoute {
  const hash = window.location.hash.replace('#/', '').replace('#', '') as PortalRoute;
  return VALID_ROUTES.includes(hash) ? hash : 'inicio';
}

export default function App() {
  const [route, setRoute] = useState<PortalRoute>(getInitialRoute);
  const [data, setData] = useState<PortalData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [token, setToken] = useState<string | null>(() =>
    sessionStorage.getItem('corte56_caa_token')
  );

  const loadPortalData = useCallback(async () => {
    try {
      const json = await fetchPublicPortalData();
      setData(json);
      setError('');
    } catch {
      setError('Não foi possível conectar ao servidor institucional.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPortalData();
  }, [loadPortalData]);

  useEffect(() => {
    const onHashChange = () => {
      setRoute(getInitialRoute());
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = (next: PortalRoute) => {
    setRoute(next);
    window.location.hash = `#/${next}`;
  };

  const handleLoginSuccess = (newToken: string) => {
    sessionStorage.setItem('corte56_caa_token', newToken);
    setToken(newToken);
  };

  const handleLogout = () => {
    sessionStorage.removeItem('corte56_caa_token');
    setToken(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#080B10] flex flex-col items-center justify-center p-6 text-center">
        <div className="w-12 h-0.5 bg-[#C5A15B] mb-4" />
        <p className="font-serif text-2xl text-[#E2C989]">
          Corte Chevalier Wilton Cunha Nº 56
        </p>
        <p className="mt-2 text-xs uppercase tracking-[0.2em] text-[#F3EFE5]/60">
          Carregando Portal Institucional...
        </p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-[#080B10] flex flex-col items-center justify-center p-6 text-center">
        <p className="font-serif text-2xl text-[#F3EFE5]">
          {error || 'Portal temporariamente indisponível.'}
        </p>
        <button
          type="button"
          onClick={() => {
            setLoading(true);
            loadPortalData();
          }}
          className="mt-5 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#8B1E24] text-[#F3EFE5] border border-[#C5A15B]/45 cursor-pointer"
        >
          Tentar Novamente
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#080B10] text-[#F3EFE5]">
      <Navbar
        currentRoute={route}
        onNavigate={navigate}
        isAdminAuthenticated={Boolean(token)}
      />

      <main className="flex-1">
        {route === 'inicio' && <HomePage data={data} onNavigate={navigate} />}
        {route === 'historia' && <HistoriaPage data={data} />}
        {route === 'atuacao' && <AtuacaoPage data={data} onNavigate={navigate} />}
        {route === 'documentos' && <DocumentosPage data={data} />}
        {route === 'locais' && <LocalGaleriaPage data={data} />}
        {route === 'admin' && (
          <AdminPage
            token={token}
            onLoginSuccess={handleLoginSuccess}
            onLogout={handleLogout}
            onPublicDataUpdated={loadPortalData}
          />
        )}
      </main>

      <Footer config={data.config} onNavigate={navigate} />
    </div>
  );
}
